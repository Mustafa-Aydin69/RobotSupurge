﻿GitHub deposu: https://github.com/Mustafa-Aydin69/RobotSupurge

ROBOT SÜPÜRGE AJANI
Yapay Zekâya Giriş dersi - Dönem İçi Proje 1

Python ile geliştirilen, farklı yapay zekâ ajanlarının iki odalı ve çok odalı
ortamlardaki davranışlarını simüle eden masaüstü uygulaması.


1. BU ZIP DOSYASININ İÇERİĞİ
----------------------------
RobotSupurge.exe   Windows için çalıştırılabilir dosya (Python gerekmez).
Kaynak Kodlar\     Programın 14 Python kaynak dosyası.
README.txt         Bu dosya.


2. OYUN NEDİR?
--------------
Bir robot süpürge (ajan), odaları kendiliğinden yeniden kirlenen bir ortamda
çalışır. Ajan yalnızca bulunduğu odayı ve o odanın temiz ya da kirli olduğunu
algılar; diğer odaları göremez. Her adımda tek bir eylem seçer: Temizle, Sola
git, Sağa git, Yukarı git ya da Aşağı git.

Amaç, farklı ajan türlerinin aynı ortamda nasıl davrandığını izlemek ve
karşılaştırmaktır. Ajanların hiçbiri makine öğrenmesi yapmaz; karar kuralları
sabittir.

Ajan türleri:

  * Basit Refleks Ajan: Yalnızca o anki algıya bakar, belleği yoktur. Oda
    kirliyse temizler, temizse başka bir odaya geçer. İki odalı ortamda:
    A kirli -> Temizle, A temiz -> Sağa git, B kirli -> Temizle,
    B temiz -> Sola git.

  * Model Tabanlı Ajan: Gördüğü odaları bir iç modelde (bellekte) saklar.
    Temiz bir odadan çıkarken önce hiç görmediği, sonra en uzun süredir
    görmediği komşu odaya gider.

  * Amaç Tabanlı Ajan: İç modeline göre bir hedef oda seçer (önce bildiği
    kirli oda, sonra hiç görmediği oda, sonra uzun süredir görmediği yakın
    oda) ve oraya BFS ile en kısa rotayı bulur.

Ortam:

  * Varsayılan ortam iki odadır: A (solda) ve B (sağda).
  * Satır ve sütun 1-6 arasında seçilerek 6x6'ya kadar grid kurulabilir
    (en az 2 oda). Büyük ortamlarda odalar A1, B3 gibi adlandırılır.
  * Kirlenme zamanlayıcısı her tetiklendiğinde temiz odaların her biri
    %30 olasılıkla yeniden kirlenir.
  * Aynı seed ile aynı başlangıç ve aynı olaylar tekrarlanır.


3. NASIL ÇALIŞTIRILIR?
----------------------
a) EXE ile (önerilen):
   RobotSupurge.exe dosyasına çift tıklayın. İlk açılış birkaç saniye
   sürebilir. EXE imzasız olduğu için Windows SmartScreen bir uyarı
   gösterebilir; "Ek bilgi" > "Yine de çalıştır" ile açabilirsiniz.

b) Kaynak koddan:
   Python 3.9 veya üzeri gerekir. "Kaynak Kodlar" klasöründe bir komut
   penceresi açıp şunları çalıştırın:

       python -m pip install ttkbootstrap==1.14.7
       python main.py

   ttkbootstrap kurulmazsa program yine çalışır, yalnızca görünümü sadeleşir.

   Pencere açmadan doğrulama (9/9 kontrol başarılı olmalı):

       python main.py --self-test


4. NASIL OYNANIR?
-----------------
Program açılınca karşılama ekranı gelir:

  * Oyna: Simülasyon ekranını açar (Enter tuşu da açar).
  * Nasıl Oynanır?: 16 adımlık etkileşimli rehberi açar. Rehber gerçek
    ekranın üzerinde her bölümü sırayla vurgulayıp açıklar. İleri: Sağ ok
    ya da Enter, Geri: Sol ok, Ana Menü: Esc.

Simülasyon ekranı:

  1. Ayarlar
     - Adım aralığı (ms): Ajanın iki adımı arasındaki süre (100-5000,
       varsayılan 700).
     - Kirlenme aralığı (sn): Kirlenme denemeleri arasındaki süre
       (0,5-60, varsayılan 3).
     - Seed: İsteğe bağlı; aynı seed aynı senaryoyu üretir.
     - Satır / Sütun: Ortam boyutu.
     - Ajan türü: Basit Refleks, Model Tabanlı ya da Amaç Tabanlı.
     Satır, sütun ve ajan türü Başlat'a basınca uygulanır.

  2. Düğmeler
     - Başlat: Yeni simülasyon başlatır.
     - Duraklat / Devam: Bekletir ya da kaldığı yerden sürdürür (Boşluk).
     - Durdur: Simülasyonu bitirir (Esc).
     - Ajanları Karşılaştır: Üç ajanı aynı koşullarda ölçen pencereyi açar.
     - Ana Menü: Karşılama ekranına döner.

  3. Gerçek Ortam
     Odaların gerçek durumu: yeşil temiz, lekeli kahverengi kirli. Mavi
     çerçeve ve robot ajanın bulunduğu odadır.

  4. Ajanın İç Modeli (Model ve Amaç Tabanlı ajanda)
     Ajanın dünya hakkındaki inancıdır, gerçek durum değildir. Gri "?"
     bilinmeyen, sarı çizgili "Eski" uzun süre önce görülmüş odadır. Amaç
     tabanlı ajanın hedefi mor çerçeve, rotası mor okla gösterilir.

  5. Simülasyon Durumu
     Durum, adım, temizleme ve hareket sayıları, kirli ve bilinen oda
     sayıları, hedef ve geçen süre.

  6. Algı ve Eylem Günlüğü
     Her adımda oda, algı (Temiz/Kirli) ve seçilen eylem. Turuncu satırlar
     kirlenmeleri, mor satırlar hedef değişimlerini gösterir.


5. AJANLARI KARŞILAŞTIRMA
-------------------------
"Ajanları Karşılaştır" penceresi üç ajanı aynı seed'lerle ve aynı başlangıçla
çalıştırıp şunları ölçer:

  * Kapsama adımı: Bütün odaların ilk kez görüldüğü adım (küçük daha hızlı).
  * Temiz oda oranı: Sürekli kirlenme altında ortalama temiz oda oranı.
  * Hareket / temizleme: Bir temizlik için yapılan hareket sayısı.

Sonuçlar ortam boyutuna ve ayarlara göre değişir; hiçbir ajan her koşulda en
iyi değildir.


Ayrıntılı dokümantasyon, testler ve EXE derleme betiği GitHub deposundadır:
https://github.com/Mustafa-Aydin69/RobotSupurge
